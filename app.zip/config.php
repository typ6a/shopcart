<?php 
	define("MYSQLSERVER","localhost"); 
	define("MYSQLDB","shop"); 
	define("MYSQLUSER","root"); 
	define("MYSQLPASSWORD","projects"); 
?>