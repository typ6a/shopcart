<?php
// Initialize the session
require_once 'loader.php'; 
require_once "views/cartView.php";