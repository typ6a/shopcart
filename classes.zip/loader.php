<?php
require_once 'config.php';
require_once 'classes/cart.php';
require_once 'functions.php';
session_start();