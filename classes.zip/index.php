<?php
require_once 'loader.php';
isLoggedIn();
require_once 'shop.php';